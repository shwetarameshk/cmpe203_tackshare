__author__ = 'Theja'
import pymongo
# Open the MongoDB connection
connMongo = pymongo.Connection('mongodb://localhost:27017')